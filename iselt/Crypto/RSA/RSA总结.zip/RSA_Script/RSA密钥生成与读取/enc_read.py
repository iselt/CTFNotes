from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from base64 import b64decode
key_info = RSA.construct((n, e, d, p, q))
key = RSA.importKey(key_info.exportKey())
key = PKCS1_OAEP.new(key)
f = open('D:\\Download\\flag.enc', 'r').read()
c = b64decode(f)
flag = key.decrypt(c)
print(flag)