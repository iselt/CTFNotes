```powershell
yafu.exe "factor(49)"
yafu.exe "factor(@)" -batchfile 1.txt
```
