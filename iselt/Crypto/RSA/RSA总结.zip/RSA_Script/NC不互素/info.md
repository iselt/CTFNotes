n c 不互质
